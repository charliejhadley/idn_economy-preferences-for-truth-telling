<center><img src="images/uni-oxford-logo.png" style="padding: 28px"/>
<img src="images/uni-nottingham-logo.png" style="padding: 28px"/>
<img src="images/logo.png" style="padding: 28px"/>
</center>

**Paper Title:** Preferences for Truth-telling.

**Authors:** Johannes Abeler, Daniele Nosenzo and Collin Raymond.

**DOI:** [http://ftp.iza.org/dp10188.pdf](http://ftp.iza.org/dp10188.pdf)

**Data Deposit:** <a href="https://doi.org/10.6084/m9.figshare.4981589" target="_blank">https://doi.org/10.6084/m9.figshare.4981589</a>

**Code Deposit:** <a href="https://doi.org/10.6084/m9.figshare.5217316" target="_blank">https://doi.org/10.6084/m9.figshare.5217316</a>

**Visualisation Developer:** Martin John Hadley

**Notes:** The data set and visualization are made available on a CC-BY license. You are free to use them in other publications as long as you credit the authors. Please link back to this page or include the following citation:

Abeler, J., Nosenzo, D. & Raymond, C. (2016) Preferences for Truth-telling, IZA Discussion Paper 10188, <a href="http://ftp.iza.org/dp10188.pdf" target="_blank">http://ftp.iza.org/dp10188.pdf</a>
